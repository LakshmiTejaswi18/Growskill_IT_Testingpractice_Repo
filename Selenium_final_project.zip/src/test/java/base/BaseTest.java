// Full Java implementation from canvas goes here
