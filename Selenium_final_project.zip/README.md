# AutomationExercise POM Suite

## Setup
1. Install JDK 11+ and Maven
2. Clone this project
3. Run `mvn clean test`

## Structure
- `base/` → BaseTest
- `pages/` → Page Object classes
- `tests/` → Test cases
- `utils/` → DriverFactory, WaitUtils

## Run
```
mvn clean test
```